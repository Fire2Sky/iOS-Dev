//
//  ViewController.h
//  CollectionViewSample
//
//  Created by 田野 on 14/12/4.
//  Copyright (c) 2014年 Fire2Sky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UICollectionViewController

@property (strong, nonatomic) NSArray * events;


@end

