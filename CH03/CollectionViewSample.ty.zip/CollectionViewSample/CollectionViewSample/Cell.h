//
//  Cell.h
//  CollectionViewSample
//
//  Created by 田野 on 14/12/8.
//  Copyright (c) 2014年 Fire2Sky. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Cell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@property (strong, nonatomic) IBOutlet UILabel *label;


@end
